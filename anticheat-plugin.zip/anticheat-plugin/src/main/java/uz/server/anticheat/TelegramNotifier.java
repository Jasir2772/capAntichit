package uz.server.anticheat;

import org.bukkit.Bukkit;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class TelegramNotifier {

    private final AntiCheatPlugin plugin;
    private final String botToken;
    private final String chatId;
    private final boolean enabled;

    public TelegramNotifier(AntiCheatPlugin plugin) {
        this.plugin = plugin;
        this.botToken = plugin.getConfig().getString("telegram.bot-token", "");
        this.chatId = plugin.getConfig().getString("telegram.chat-id", "");
        this.enabled = plugin.getConfig().getBoolean("telegram.enabled", true)
                && !botToken.isBlank() && !chatId.isBlank();

        if (plugin.getConfig().getBoolean("telegram.enabled", true) && !this.enabled) {
            plugin.getLogger().warning("Telegram yoqilgan, lekin bot-token yoki chat-id config.yml da to'ldirilmagan!");
        }
    }

    public void sendMessage(String text) {
        if (!enabled) return;

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                String urlStr = "https://api.telegram.org/bot" + botToken + "/sendMessage";
                URL url = new URL(urlStr);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setDoOutput(true);

                String params = "chat_id=" + URLEncoder.encode(chatId, StandardCharsets.UTF_8)
                        + "&text=" + URLEncoder.encode(text, StandardCharsets.UTF_8)
                        + "&parse_mode=Markdown";

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(params.getBytes(StandardCharsets.UTF_8));
                }

                int code = conn.getResponseCode();
                if (code != 200) {
                    plugin.getLogger().warning("[AntiCheat] Telegramga xabar yuborishda xatolik, kod: " + code);
                }
                conn.disconnect();
            } catch (Exception e) {
                plugin.getLogger().warning("[AntiCheat] Telegram xatosi: " + e.getMessage());
            }
        });
    }
}
