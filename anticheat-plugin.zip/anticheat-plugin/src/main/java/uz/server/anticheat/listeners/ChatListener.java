package uz.server.anticheat.listeners;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import uz.server.anticheat.AntiCheatPlugin;
import uz.server.anticheat.PlayerData;

public class ChatListener implements Listener {

    private final AntiCheatPlugin plugin;
    private final int maxMessagesPerWindow;
    private final long windowMillis;
    private final double muteThreshold;

    public ChatListener(AntiCheatPlugin plugin) {
        this.plugin = plugin;
        this.maxMessagesPerWindow = plugin.getConfig().getInt("chat.max-messages-per-window", 5);
        this.windowMillis = plugin.getConfig().getLong("chat.window-seconds", 5) * 1000L;
        this.muteThreshold = plugin.getConfig().getDouble("chat.mute-threshold", 5.0);
    }

    @EventHandler
    public void onChat(AsyncChatEvent event) {
        Player player = event.getPlayer();
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        long now = System.currentTimeMillis();
        String message = PlainTextComponentSerializer.plainText().serialize(event.message()).trim().toLowerCase();

        // Takroriy xabar
        if (!data.lastMessage.isEmpty() && data.lastMessage.equals(message)) {
            data.chatViolationLevel += 2;
            plugin.getLogger().info("[AntiCheat] " + player.getName() + " -> Takroriy xabar | VL: " + data.chatViolationLevel);
        }
        data.lastMessage = message;

        // Flood (vaqt oynasidagi xabarlar soni)
        data.messageTimestamps.addLast(now);
        while (!data.messageTimestamps.isEmpty() && now - data.messageTimestamps.peekFirst() > windowMillis) {
            data.messageTimestamps.pollFirst();
        }
        if (data.messageTimestamps.size() > maxMessagesPerWindow) {
            data.chatViolationLevel += 1.5;
            plugin.getLogger().info("[AntiCheat] " + player.getName() + " -> Spam/flood | VL: " + data.chatViolationLevel);
        }

        if (data.chatViolationLevel >= muteThreshold) {
            plugin.getPunishmentManager().mutePlayer(player,
                    "Chatda spam/flood (VL: " + String.format("%.1f", data.chatViolationLevel) + ")");
            data.chatViolationLevel = 0;
        }
    }
}
