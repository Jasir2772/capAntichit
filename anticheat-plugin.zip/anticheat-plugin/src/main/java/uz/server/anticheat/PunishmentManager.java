package uz.server.anticheat;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class PunishmentManager {

    private final AntiCheatPlugin plugin;
    private final TelegramNotifier telegram;
    private final String banDuration;
    private final String muteDuration;

    public PunishmentManager(AntiCheatPlugin plugin, TelegramNotifier telegram) {
        this.plugin = plugin;
        this.telegram = telegram;
        this.banDuration = plugin.getConfig().getString("punishments.ban-duration", "30d");
        this.muteDuration = plugin.getConfig().getString("punishments.mute-duration", "10m");
    }

    // LiteBans o'zining /tempban va /tempmute buyruqlarini qayta belgilaydi,
    // shuning uchun bu buyruqlarni konsoldan chaqirish LiteBans orqali ishlaydi.
    public void banPlayer(Player player, String reason) {
        String cmd = "tempban " + player.getName() + " " + banDuration + " [AntiCheat] " + reason;
        Bukkit.getScheduler().runTask(plugin, () ->
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd));

        telegram.sendMessage("⛔ *" + escape(player.getName()) + "* o'yinchisi *BAN* oldi.\n"
                + "Sabab: " + escape(reason) + "\n"
                + "Muddat: " + banDuration);
    }

    public void mutePlayer(Player player, String reason) {
        String cmd = "tempmute " + player.getName() + " " + muteDuration + " [AntiCheat] " + reason;
        Bukkit.getScheduler().runTask(plugin, () ->
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd));

        telegram.sendMessage("🔇 *" + escape(player.getName()) + "* o'yinchisi *MUTE* oldi.\n"
                + "Sabab: " + escape(reason) + "\n"
                + "Muddat: " + muteDuration);
    }

    private String escape(String text) {
        return text.replace("_", "\\_").replace("*", "\\*").replace("`", "\\`");
    }
}
