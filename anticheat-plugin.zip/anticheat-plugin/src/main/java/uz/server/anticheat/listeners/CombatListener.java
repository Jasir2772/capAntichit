package uz.server.anticheat.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import uz.server.anticheat.AntiCheatPlugin;
import uz.server.anticheat.PlayerData;

import java.util.Deque;

public class CombatListener implements Listener {

    private final AntiCheatPlugin plugin;

    private final double maxReach;
    private final double minNaturalYawVariance;
    private final int maxCps;
    private final double vlDecayPerSecond;
    private final double banThreshold;

    public CombatListener(AntiCheatPlugin plugin) {
        this.plugin = plugin;
        this.maxReach = plugin.getConfig().getDouble("combat.max-reach", 3.3);
        this.minNaturalYawVariance = plugin.getConfig().getDouble("combat.min-yaw-variance", 1.5);
        this.maxCps = plugin.getConfig().getInt("combat.max-cps", 18);
        this.vlDecayPerSecond = plugin.getConfig().getDouble("combat.vl-decay-per-second", 0.5);
        this.banThreshold = plugin.getConfig().getDouble("combat.ban-threshold", 20.0);
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;

        PlayerData data = plugin.getPlayerData(attacker.getUniqueId());
        long now = System.currentTimeMillis();

        // Vaqt o'tishi bilan VL pasayadi (xato (false positive) larni kamaytirish uchun)
        if (data.lastAttackTime > 0) {
            double secondsPassed = (now - data.lastAttackTime) / 1000.0;
            data.combatViolationLevel = Math.max(0, data.combatViolationLevel - secondsPassed * vlDecayPerSecond);
        }

        // 1) REACH (masofadan urish) tekshiruvi
        double distance = attacker.getLocation().distance(event.getEntity().getLocation());
        if (distance > maxReach) {
            addViolation(data, 3, attacker, "Reach (" + String.format("%.2f", distance) + " blok)");
        }

        // 2) CPS (soniyadagi urishlar soni) tekshiruvi
        data.clickTimestamps.addLast(now);
        while (!data.clickTimestamps.isEmpty() && now - data.clickTimestamps.peekFirst() > 1000) {
            data.clickTimestamps.pollFirst();
        }
        if (data.clickTimestamps.size() > maxCps) {
            addViolation(data, 1, attacker, "Yuqori CPS (" + data.clickTimestamps.size() + ")");
        }

        // 3) Aim-assist / Kill Aura: burchak o'zgarishi juda "bir xil" bo'lsa (inson qarashi har doim bir xil tezlikda o'zgarmaydi)
        float yaw = attacker.getLocation().getYaw();
        if (data.lastAttackTime > 0 && now - data.lastAttackTime < 1500) {
            double yawDelta = Math.abs(normalizeAngle(yaw - data.lastYaw));
            data.yawDeltaHistory.addLast(yawDelta);
            if (data.yawDeltaHistory.size() > 10) data.yawDeltaHistory.pollFirst();

            if (data.yawDeltaHistory.size() >= 6) {
                double variance = variance(data.yawDeltaHistory);
                double average = average(data.yawDeltaHistory);
                if (variance < minNaturalYawVariance && average > 2.0) {
                    addViolation(data, 2, attacker, "Aim-assist (variance: " + String.format("%.2f", variance) + ")");
                }
            }
        }
        data.lastYaw = yaw;
        data.lastAttackTime = now;

        // Avtomatik jazo
        if (data.combatViolationLevel >= banThreshold) {
            plugin.getPunishmentManager().banPlayer(attacker,
                    "KillAura/Aim-assist (VL: " + String.format("%.1f", data.combatViolationLevel) + ")");
            data.combatViolationLevel = 0;
        }
    }

    private void addViolation(PlayerData data, double amount, Player player, String reasonDetail) {
        data.combatViolationLevel += amount;
        plugin.getLogger().info("[AntiCheat] " + player.getName() + " -> " + reasonDetail
                + " | VL: " + String.format("%.1f", data.combatViolationLevel));
    }

    private double normalizeAngle(double angle) {
        angle %= 360;
        if (angle < -180) angle += 360;
        if (angle > 180) angle -= 360;
        return angle;
    }

    private double average(Deque<Double> values) {
        if (values.isEmpty()) return 0;
        double sum = 0;
        for (double v : values) sum += v;
        return sum / values.size();
    }

    private double variance(Deque<Double> values) {
        if (values.isEmpty()) return 0;
        double avg = average(values);
        double sum = 0;
        for (double v : values) sum += (v - avg) * (v - avg);
        return sum / values.size();
    }
}
