package uz.server.anticheat;

import java.util.ArrayDeque;
import java.util.Deque;

public class PlayerData {

    // Combat (jang) kuzatuvi
    public double combatViolationLevel = 0;
    public long lastAttackTime = 0;
    public float lastYaw = 0;
    public float lastPitch = 0;
    public final Deque<Long> clickTimestamps = new ArrayDeque<>();
    public final Deque<Double> yawDeltaHistory = new ArrayDeque<>();

    // Chat kuzatuvi
    public double chatViolationLevel = 0;
    public String lastMessage = "";
    public final Deque<Long> messageTimestamps = new ArrayDeque<>();
}
