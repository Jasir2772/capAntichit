package uz.server.anticheat;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import uz.server.anticheat.listeners.ChatListener;
import uz.server.anticheat.listeners.CombatListener;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class AntiCheatPlugin extends JavaPlugin implements Listener {

    private static AntiCheatPlugin instance;
    private final Map<UUID, PlayerData> playerDataMap = new HashMap<>();
    private PunishmentManager punishmentManager;
    private TelegramNotifier telegramNotifier;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        this.telegramNotifier = new TelegramNotifier(this);
        this.punishmentManager = new PunishmentManager(this, telegramNotifier);

        getServer().getPluginManager().registerEvents(this, this);
        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(new ChatListener(this), this);

        getLogger().info("AntiCheat plagin yoqildi. Versiya: " + getDescription().getVersion());

        if (getServer().getPluginManager().getPlugin("LiteBans") == null) {
            getLogger().warning("LiteBans topilmadi! Ban/mute buyruqlari ishlamasligi mumkin.");
        }
    }

    @Override
    public void onDisable() {
        getLogger().info("AntiCheat plagin o'chirildi.");
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        playerDataMap.remove(event.getPlayer().getUniqueId());
    }

    public static AntiCheatPlugin getInstance() {
        return instance;
    }

    public PlayerData getPlayerData(UUID uuid) {
        return playerDataMap.computeIfAbsent(uuid, k -> new PlayerData());
    }

    public PunishmentManager getPunishmentManager() {
        return punishmentManager;
    }

    public TelegramNotifier getTelegramNotifier() {
        return telegramNotifier;
    }
}
