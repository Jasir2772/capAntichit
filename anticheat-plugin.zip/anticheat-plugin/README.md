# AntiCheat Plugin — O'rnatish Qo'llanmasi

Paper 1.21.4 uchun, LiteBans va Telegram integratsiyasi bilan avtomatik anticheat.

## 1-QADAM: Telegram bot yaratish

1. Telegramda **@BotFather** ni toping va yozing: `/newbot`
2. Botga nom bering (masalan: `Server AntiCheat Bot`)
3. Username bering (masalan: `my_server_anticheat_bot`) — `bot` bilan tugashi shart
4. BotFather sizga **token** beradi, masalan:
   `7123456789:AAH4k2j9XyZ...` — buni saqlab qo'ying

## 2-QADAM: Chat ID olish

Agar xabarlar **shaxsiy sizga** kelsin desangiz:
1. O'zingiz yaratgan bot bilan suhbatni boshlang (`/start` bosing)
2. Brauzerda oching:
   `https://api.telegram.org/bot<TOKEN>/getUpdates`
   (`<TOKEN>` o'rniga o'z tokeningizni qo'ying)
3. Natijada `"chat":{"id":123456789,...}` qismini topasiz — shu raqam sizning **chat_id**

Agar xabarlar **guruhga** kelsin desangiz:
1. Botni guruhga qo'shing va admin qiling
2. Guruhda biror xabar yozing
3. Yuqoridagi `getUpdates` havolasini oching — guruh uchun `id` manfiy raqam bo'ladi (masalan `-1001234567890`)

## 3-QADAM: config.yml ni to'ldirish

`src/main/resources/config.yml` faylini oching va quyidagilarni almashtiring:

```yaml
telegram:
  enabled: true
  bot-token: "7123456789:AAH4k2j9XyZ..."
  chat-id: "123456789"
```

## 4-QADAM: Build qilish

Kompyuteringizda **Java 17+** va **Maven** o'rnatilgan bo'lishi kerak.

```bash
cd anticheat-plugin
mvn clean package
```

Build tugagach, `target/anticheat.jar` fayli paydo bo'ladi.

## 5-QADAM: Serverga o'rnatish

1. **LiteBans** pluginini oldin o'rnating (agar hali o'rnatilmagan bo'lsa): https://www.spigotmc.org/resources/litebans.3715/
2. `anticheat.jar` faylini serveringizning `plugins/` papkasiga joylashtiring
3. Serverni qayta ishga tushiring
4. `plugins/AntiCheat/config.yml` fayli avtomatik yaratiladi — agar oldindan to'ldirmagan bo'lsangiz, shu yerda to'ldiring va serverni qayta ishga tushiring (yoki `/reload`, lekin bu tavsiya etilmaydi)

## Sozlamalarni moslashtirish

`config.yml` dagi quyidagi qiymatlarni serveringiz holatiga qarab o'zgartirishingiz mumkin:

- `combat.ban-threshold` — qancha past bo'lsa, shuncha tez ban beradi (lekin xato ehtimoli oshadi)
- `combat.max-reach` — vanilla Minecraft'da odatda ~3.0-3.1 blok normal
- `chat.max-messages-per-window` — chatda ruxsat etilgan tezlik

**Tavsiya:** birinchi 1-2 hafta `ban-threshold` va `mute-threshold` ni odatdagidan yuqoriroq qilib qo'ying va loglarni kuzating (`[AntiCheat]` yozuvlari konsolda chiqadi), haqiqiy o'yinchilar bexato o'ynayotganiga ishonch hosil qilgach pasaytiring. Aks holda vijdonli o'yinchilar noto'g'ri ban olishi mumkin.

## Muhim eslatma

Bu tizim evristik (qoidaga asoslangan) anticheat bo'lib, 100% xatosiz emas — hech qanday anticheat (hatto Grim yoki Vulcan kabi professional yechimlar ham) mutlaq aniqlikka ega emas. Shuning uchun:

- Loglarni muntazam kuzatib boring
- Shubhali ban/mute larni adminlar tekshirib, kerak bo'lsa bekor qila olishini ta'minlang (`/unban`, `/unmute` — LiteBans buyruqlari)
- Threshold larni serveringiz o'yinchilari tajribasiga qarab moslang
